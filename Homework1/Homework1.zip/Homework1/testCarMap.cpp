//
//  testCarMap.cpp
//  Homework1
//
//  Created by Vivianne Dinh on 1/21/20.
//  Copyright © 2020 Vivianne Dinh. All rights reserved.
//

#include <stdio.h>
